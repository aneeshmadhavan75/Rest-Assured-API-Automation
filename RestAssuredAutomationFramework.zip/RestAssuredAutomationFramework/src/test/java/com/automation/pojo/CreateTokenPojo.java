package com.automation.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateTokenPojo {
    String username;
    String password;
}
