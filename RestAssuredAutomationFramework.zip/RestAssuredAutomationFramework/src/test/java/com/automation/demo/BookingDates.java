package com.automation.demo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingDates {
    String checkin;
    String checkout;

}
